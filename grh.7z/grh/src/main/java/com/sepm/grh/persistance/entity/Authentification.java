package com.sepm.grh.persistance.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Authentification {

	@Id
	private Long matricule;
	private String password;

}
