package com.sepm.grh.persistance.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity

public class Message {

	@Id
	private Long id;
	private Long matricule;
	private String objet;
	private String message;
	private LocalDateTime dateMsg;
	private String statut;

}
