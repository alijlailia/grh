package com.sepm.grh.persistance.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Conge {

	@Id
	private Long id;
	private Long matricule;
	private LocalDateTime dateDemande;
	private LocalDate dateDebut;
	private LocalDate dateFin;
	private Boolean statut;

}
