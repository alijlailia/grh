package com.sepm.grh.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sepm.grh.persistance.entity.Employe;
import com.sepm.grh.service.EmployeService;
import com.sepm.grh.util.Fonction;

@Controller
@RequestMapping(value = "/employe")
public class EmployeController {

	@Autowired
	private EmployeService employeService;

	@GetMapping("/employeList")
	public String getEmployeList(Model model) {
		List<Employe> employeList = employeService.getEmployeList();
		model.addAttribute("employeList", employeList);
		return "/employe/employeList.html";
	}

	@GetMapping("/employeList/{matricule}")
	public String getEmploye(Model model, @PathVariable Long matricule) {
		Employe employe = employeService.getEmploye(matricule);
		model.addAttribute("employe", employe);
		return "/employe/employe.html";
	}

	@GetMapping("/ajoutEmploye")
	public String ajoutEmployeGet(Model model, @ModelAttribute Employe employe) {
		model.addAttribute("employe", employe);
		model.addAttribute("fonctions", Fonction.values());

		List<Employe> directeurs = employeService.getEmployeByFonction(Fonction.DIRECTEUR);
		List<Employe> cadres = employeService.getEmployeByFonction(Fonction.CADRE);
		List<Employe> chefs = employeService.getEmployeByFonction(Fonction.CHEF);

		List<Employe> responsables = new ArrayList<>();
		responsables.addAll(directeurs);
		responsables.addAll(cadres);
		responsables.addAll(chefs);

		model.addAttribute("responsables", responsables);

		return "/employe/ajoutEmploye.html";
	}

	@PostMapping("/ajoutEmploye")
	public String ajoutEmployePost(Model model, @ModelAttribute Employe employe) {
		Employe employeDataBase = employeService.ajouterEmploye(employe);
		return "redirect:/employe/employeList/" + employeDataBase.getMatricule();
	}

}
