package com.sepm.grh.persistance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sepm.grh.persistance.entity.Employe;
import com.sepm.grh.util.Fonction;

public interface EmployeRepository extends JpaRepository<Employe, Long> {

	List<Employe> findByFonction(Fonction fonction);

}
