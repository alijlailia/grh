package com.sepm.grh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrhApplicationTests {

	@Test
	void contextLoads() {
	}

}
