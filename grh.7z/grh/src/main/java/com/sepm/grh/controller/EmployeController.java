package com.sepm.grh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.sepm.grh.persistance.entity.Employe;
import com.sepm.grh.service.EmployeService;

@Controller
public class EmployeController {

	@Autowired
	private EmployeService employeService;

	@GetMapping("/")
	public String index() {
		return "index.html";
	}

	@GetMapping("/employeList")
	public String getEmployeList(Model model) {
		List<Employe> employeList = employeService.getEmployeList();
		model.addAttribute("employeList", employeList);
		return "/employe/employeList.html";
	}

	@GetMapping("/employeList/{matricule}")
	public String getEmploye(Model model, @PathVariable Long matricule) {
		Employe employe = employeService.getEmploye(matricule);
		model.addAttribute("employe", employe);
		return "/employe/employe.html";
	}

	@GetMapping("/ajoutEmploye")
	public String ajoutEmployeGet(Model model, @ModelAttribute Employe employe) {
		model.addAttribute("employe", employe);
		return "/employe/ajoutEmploye.html";
	}

	@PostMapping("/ajoutEmploye")
	public String ajoutEmployePost(Model model, @ModelAttribute Employe employe) {
		Employe employeDataBase = employeService.ajouterEmploye(employe);
		return "redirect:/employeList/" + employeDataBase.getMatricule();
	}

}
