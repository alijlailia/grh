package com.sepm.grh.util;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import com.sepm.grh.persistance.entity.Employe;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@SessionScope
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SessionInfo {

	private Employe employe;

}
