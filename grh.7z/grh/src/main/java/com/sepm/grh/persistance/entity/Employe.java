package com.sepm.grh.persistance.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Employe {

	@Id
	private Long matricule;
	private String nom;
	private String prenom;
	private String fonction;
	private Integer numCin;
	private Integer numCnss;
	private LocalDate dateNaissance;
	private String adresse;

}
