package com.sepm.grh.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sepm.grh.persistance.entity.Authentification;
import com.sepm.grh.persistance.repository.AuthentificationRepository;

@Service
public class AuthentificationService {

	@Autowired
	private AuthentificationRepository authentificationRepository;

	public Authentification getAuthentification(Long matricule) {
		return authentificationRepository.findById(matricule).orElse(null);
	}

}
