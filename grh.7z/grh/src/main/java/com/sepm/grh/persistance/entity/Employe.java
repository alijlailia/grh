package com.sepm.grh.persistance.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

import com.sepm.grh.util.Fonction;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Employe {

	@Id
	private Long matricule;
	private String nom;
	private String prenom;
	private String email;
	private String tel;
	private String adresse;
	private LocalDate dateNaissance;
	@Enumerated(EnumType.STRING)
	private Fonction fonction;
	private Integer numCin;
	private Integer numCnss;

	private Long matriculeResponsable;

}
