package com.sepm.grh.util;

public enum Fonction {

	DIRECTEUR, CADRE, CHEF, OUVRIER

}
