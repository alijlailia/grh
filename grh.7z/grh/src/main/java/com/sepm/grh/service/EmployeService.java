package com.sepm.grh.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sepm.grh.persistance.entity.Employe;
import com.sepm.grh.persistance.repository.EmployeRepository;
import com.sepm.grh.util.Fonction;

@Service
public class EmployeService {

	@Autowired
	private EmployeRepository employeRepository;

	public List<Employe> getEmployeList() {
		return employeRepository.findAll();
	}

	public Employe getEmploye(Long matricule) {
		return employeRepository.findById(matricule).get();
	}

	public Employe ajouterEmploye(Employe employe) {
		return employeRepository.save(employe);
	}

	public List<Employe> getEmployeByFonction(Fonction fonction) {
		return employeRepository.findByFonction(fonction);
	}

}
