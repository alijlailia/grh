package com.sepm.grh.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.SecurityFilterChain;

import com.sepm.grh.persistance.entity.Authentification;
import com.sepm.grh.persistance.entity.Employe;
import com.sepm.grh.service.AuthentificationService;
import com.sepm.grh.service.EmployeService;
import com.sepm.grh.util.SessionInfo;

@EnableWebSecurity
public class WebSecurityConfig {

	@Autowired
	private AuthentificationService authentificationService;

	@Autowired
	private EmployeService employeService;

	@Autowired
	private SessionInfo sessionInfo;

	// @formatter:off
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http
			.authorizeRequests()
				.antMatchers("/bootstrap-5.2.0/**", "/css/**", "/js/**", "/img/**").permitAll()
				.anyRequest().authenticated()
				.and()
			.formLogin()
				.loginPage("/login")
				.permitAll()
				.and()
			.logout()
				.permitAll()
				.and()
			.httpBasic();

		return http.build();
	}
	// @formatter:on

	@Bean
	public UserDetailsService userDetailsService() {

		return new UserDetailsService() {
			@Override
			public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
				Long matricule;
				try {
					matricule = Long.valueOf(username);
				} catch (NumberFormatException e) {
					throw new UsernameNotFoundException("Le matricule n'est pas valide");
				}

				Authentification authentification = authentificationService.getAuthentification(matricule);
				if (authentification == null) {
					throw new UsernameNotFoundException("Le compte n'existe pas");
				}

				Employe employe = employeService.getEmploye(matricule);
				List<SimpleGrantedAuthority> authorities = List
						.of(new SimpleGrantedAuthority(employe.getFonction().name()));

				// Enregistrer l'employé connecté dans la session
				sessionInfo.setEmploye(employe);

				return new User(username, authentification.getPassword(), authorities);
			}
		};

	}

}