package com.sepm.grh.persistance.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity

public class Pointage {

	@Id
	private Long id;
	private Long matriculeChef;
	private Long matriculeEmploye;
	private int mois;
	private int nombreJours;
	private int heuresSupp;
	private String lieuTrvail;
	private LocalDateTime datePointage;
	private String statut;

}
